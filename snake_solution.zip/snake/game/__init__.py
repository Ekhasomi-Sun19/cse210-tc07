"""
The game package contains specific classes for playing Hunter.
"""